// Character Variables
var characterX = 100;
var characterY = 100;
// Key Codes Defined
var U = 85; 
var P = 80;
var A = 65;
var F = 70;
// Shape Variables
var shapeX = 25;
var shapeY = 50;
var shapeXSpeed;
var shapeYSpeed;

// Mouse click (Creates Square)
var mouseShapeX;
var mouseShapeY;
p5.disableFriendlyErrors = true;

function setup()
{
    createCanvas(800, 800);
    // Random Speed
    shapeXSpeed = Math.floor(Math.random() * (Math.floor(Math.random() * 2)) + 1);
    shapeYSpeed = Math.floor(Math.random() * (Math.floor(Math.random() * 2)) + 1);
}
function draw()
{
    background(200,200,0);
  //border
  function callborder(thickness)
{
    // top 
    rect(0,0,width,thickness);
    // left 
    rect(0,0,thickness,height);
    // bottom 
    rect(0, height-thickness,width, thickness);
    // right 
    rect(width-thickness,0,thickness,height);
}
  callborder(10);

    // End Game
  function callendgame()
  {
  textSize(16);
    text("Exit", width-50,height-50)
  }
  callendgame();

  //I am the Black Circle
  function callblackcircle()
  {
    fill(25,50,50);
    circle(characterX,characterY,50);
  }
callblackcircle();
  
// Blue Square
function callbluesquare()
  {
  fill(0,0,200);
  square(400,400,30); 
  }
  callbluesquare();
  
  // Key Movements
    if(keyIsDown(U))
    {
        characterY -= 10;   
    }
    if(keyIsDown(P))
    {
        characterY += 10;   
    }
    if(keyIsDown(A))
    {
        characterX -= 10;   
    }
    if(keyIsDown(F))
    {
        characterX += 10;  
    }
    // Enemy
    fill(13,145,14);
    circle(shapeX, shapeY, 10);
    // Random Speed
     shapeXSpeed = Math.floor(Math.random() * (Math.floor(Math.random() * 5)) + 1);
     shapeYSpeed = Math.floor(Math.random() * (Math.floor(Math.random() * 5)) + 1);
  
    // Enemy Movement
    shapeX += shapeXSpeed;
    shapeY += shapeYSpeed;
    // 
    if(shapeX > width)
    {
        shapeX = 0;
    }
    if(shapeX < 0)
    {
        shapeX = width;
    }
    if(shapeY > height)
    {
        shapeY = 0;
    }
    if(shapeY < 0)
    {
        shapeY = height;
    }

    // Enemy Return (off screen)
    if(characterX >=width-50 && characterY >=height-50)
    {
        fill(0);
        stroke(5);
        textSize(26);
        text("You Win!", 200, 200);
    }

    // Shape 2 (Square by mouse)  
    fill(120,130,140);
    square(mouseShapeX, mouseShapeY, 50);

}

function mouseClicked()
{
    mouseShapeX = mouseX;
    mouseShapeY = mouseY;
}
function keyPressed() {
    if (keyCode === LEFT_ARROW) {
        characterX -= 20;
    } 
    else if (keyCode === RIGHT_ARROW) {
        characterX += 20;
    }
    else if (keyCode === UP_ARROW) {
        characterY -= 20;
    }
    else if (keyCode === DOWN_ARROW) {
        characterY += 20;
    }

  }
