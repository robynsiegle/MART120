// Character Variables
var characterX = 100;
var characterY = 100;
// Key Codes Defined
var W = 087;
var S = 083;
var A = 65;
var D = 068;
// Shape Variables
var shapeXs = 25;
var shapeYs = 50;
var shapeXSpeeds = [];
var shapeYSpeeds = [];
var myXs = [];
var myYs = [];
var myDiameters = [];

// Mouse click (Creates Square)
var mouseShapeX;
var mouseShapeY;
p5.disableFriendlyErrors = true;

function setup() {
    createCanvas(800, 800);
    var x = 50;
    var y = 50;
    var diameter = 25;
    for (var i = 0; i < 5; i++) {
        myXs[i] = getRandomNumber(500);
        myYs[i] = getRandomNumber(600);
        myDiameters[i] = getRandomNumber(30);

        // Random Speed
        shapeXSpeeds[i] = Math.floor(Math.random() * 10) + 1;
        shapeYSpeeds[i] = Math.floor(Math.random() * 10) + 1;
    }
    //This won't work if I put it in draw. It grays everything out and freezes
 shapeXs[i] += shapeXSpeeds[i];
        shapeYs[i] += shapeYSpeeds[i];
        // check to see if the shape has gone out of bounds
        if (shapeXs[i] > 10) {
            shapeXs[i] = 0;
        }
        if (shapeXs[i] < 0) {
            shapeXs[i] = 10;
        }
        if (shapeYs[i] > 10) {
            shapeYs[i] = 0;
        }
        if (shapeYs[i] < 0) {
            shapeYs[i] = 10;
        }
}


function draw() {
    background(200, 200, 0);

    for (var i = 0; i < myXs.length; i++) {
        // draw your circles here
        // use the array names
        circle(myXs[i], myYs[i], myDiameters[i]);
        myXs[i] += shapeXSpeeds[i];
        myYs[i] += shapeYSpeeds[i];
        // check to see if the shape has gone out of bounds
        if (myXs[i] > width) {
            myXs[i] = 0;
        }
        if (myXs[i] < 0) {
            myXs[i] = 10;
        }
        if (myYs[i] > height) {
            myYs[i] = 0;
        }
        if (myYs[i] < 0) {
            myYs[i] = 10;
        }
    } // new end of for loop now
    callborder(10);
    callbluesquare();
    callendgame();
    callblackcircle();
    moveCharacter();
    createSquareFromMouse();
}

//border
function callborder(thickness) {

    // top 
    rect(0, 0, width, thickness);
    // left 
    rect(0, 0, thickness, height);
    // bottom 
    rect(0, height - thickness, width, thickness);
    // right 
    rect(width - thickness, 0, thickness, height);
}

function ConcentricCircle(x, y, outer_diameter, inner_diameter, outer_red, outer_green, outer_blue, inner_red, inner_green, inner_blue) {
    fill(outer_red, outer_green, outer_blue);
    circle(x, y, outer_diameter);
    fill(inner_red, inner_green, inner_blue);
    circle(x, y, inner_diameter);
}

function changeDiameter() {
    if (diameter < 200) {
        diameter += 2;
    } else if (diameter >= 200) {
        diameter = 25;
    }

}

// End Game
function callendgame() {
    textSize(16);
    text("Exit", width - 50, height - 50)
}

//I am the Black Circle
function callblackcircle() {
    fill(25, 50, 50);
    circle(characterX, characterY, 50);
}

// Blue Square
function callbluesquare() {
    fill(0, 0, 200);
    square(400, 400, 30);
}

function moveCharacter() {


    // Key Movements 
    // you might consider changing these to WASD just for ease of movement
    if (keyIsDown(W)) {
        characterY -= 10;
    }
    if (keyIsDown(S)) {
        characterY += 10;
    }
    if (keyIsDown(A)) {
        characterX -= 10;
    }
    if (keyIsDown(D)) {
        characterX += 10;
    }

    if (characterX >= width - 50 && characterY >= height - 50) {
        fill(0);
        stroke(5);
        textSize(26);
        text("You Win!", 200, 200);
    }
}

// Shape 2 (Square by mouse)  
// need to create a function and call it
function createSquareFromMouse() {
    fill(120, 130, 140);
    square(mouseShapeX, mouseShapeY, 50);
}

//}

function mouseClicked() {
    mouseShapeX = mouseX;
    mouseShapeY = mouseY;
}

function keyPressed() {
    if (keyCode === LEFT_ARROW) {
        characterX -= 20;
    } else if (keyCode === RIGHT_ARROW) {
        characterX += 20;
    } else if (keyCode === UP_ARROW) {
        characterY -= 20;
    } else if (keyCode === DOWN_ARROW) {
        characterY += 20;
    }
}

function getRandomNumber(number) {
    return Math.floor(Math.random() * number) + 10;
}