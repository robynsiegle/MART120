// Character Variables
var characterX = 100;
var characterY = 100;
// Key Codes Defined
var a = 85; 
var b = 80;
var c = 60;
var d = 65;
// Shape Variables
var shapeX = 25;
var shapeY = 50;
var shapeXSpeed;
var shapeYSpeed;

// Mouse click (Creates Square)
var mouseShapeX;
var mouseShapeY;

function setup()
{
    createCanvas(800, 800);
    // Random Speed
    shapeXSpeed = Math.floor(Math.random() * (Math.floor(Math.random() * 2)) + 1);
    shapeYSpeed = Math.floor(Math.random() * (Math.floor(Math.random() * 2)) + 1);
}
function draw()
{
    background(200,200,0);
  
    // End Game
    textSize(16);
    text("Exit", width-50,height-50)

  //I am the Black Circle
    fill(25,50,50);
    circle(characterX,characterY,50);
  
  // I am a non moving square
  fill(0,0,200);
  square(400,400,30);
  
  // Key Movements
    if(keyIsDown(a))
    {
        characterY -= 10;   
    }
    if(keyIsDown(b))
    {
        characterY += 10;   
    }
    if(keyIsDown(c))
    {
        characterX -= 10;   
    }
    if(keyIsDown(d))
    {
        characterX += 10;  
    }
    // Enemy
    fill(13,145,14);
    // 
    circle(shapeX, shapeY, 10);
    // Random Speed
     shapeXSpeed = Math.floor(Math.random() * (Math.floor(Math.random() * 5)) + 1);
     shapeYSpeed = Math.floor(Math.random() * (Math.floor(Math.random() * 5)) + 1);
  
    // Enemy Movement
    shapeX += shapeXSpeed;
    shapeY += shapeYSpeed;
    // 
    if(shapeX > width)
    {
        shapeX = 0;
    }
    if(shapeX < 0)
    {
        shapeX = width;
    }
    if(shapeY > height)
    {
        shapeY = 0;
    }
    if(shapeY < 0)
    {
        shapeY = height;
    }

    // Enemy Return (off screen)
    if(characterX <=2-50 && characterY <=2-50)
    {
        fill(0);
        stroke(5);
        textSize(26);
        text("You Win!", 200, 200);
    }

    // Shape 2 (Square by mouse)
    fill(120,130,140);
    square(mouseShapeX, mouseShapeY, 50);

}

function mouseClicked()
{
    mouseShapeX = mouseX;
    mouseShapeY = mouseY;
}
function keyPressed() {
    if (keyCode === LEFT_ARROW) {
        characterX -= 20;
    } 
    else if (keyCode === RIGHT_ARROW) {
        characterX += 20;
    }
    else if (keyCode === UP_ARROW) {
        characterY -= 20;
    }
    else if (keyCode === DOWN_ARROW) {
        characterY += 20;
    }
  }
